package cvtc.edu.shapes;


public class Sphere extends Shape{


    //declare variables
    float radius = 0;


    //constructor

    public Sphere(float radius) {
        this.radius = radius;
    }


    //Getters and Setters


    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    @Override
    public float surfaceArea() {
        return (float) (4 * Math.PI * (Math.pow(radius, 2)));
    }

    @Override
    public float volume() {
        return (float) (4 * Math.PI * (Math.pow(radius, 3) / 3));
    }

    @Override
    public String render() {

        return "The surface area of the object is " + surfaceArea() + "The volume is " + volume();


    }
}
