package cvtc.edu.shapes;

import javax.swing.*;
import java.awt.*;

public class ShapesTest {
    public static void main(String[] args){

        Sphere sphere = new Sphere(5);
        Cylinder cylinder = new Cylinder(5,10);
        Cuboid cube = new Cuboid(5,5,20);

        Component frame = null;
        JOptionPane.showMessageDialog(frame, sphere.render());
        JOptionPane.showMessageDialog(frame, cylinder.render());
        JOptionPane.showMessageDialog(frame, cube.render());


    }


}
