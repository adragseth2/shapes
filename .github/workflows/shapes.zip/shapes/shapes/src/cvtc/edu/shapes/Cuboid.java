package cvtc.edu.shapes;

public class Cuboid extends Shape {

    //declare variables

    float width = 0;
    float height = 0;
    float depth = 0;


    //constructor

    public Cuboid(float width, float height, float depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
    }


    //generated getters and setters


    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getDepth() {
        return depth;
    }

    public void setDepth(float depth) {
        this.depth = depth;
    }

    //override functions
    @Override
    public float surfaceArea() {

        return (float) 2 * (depth * height) + 2 * (depth * width) + 2 *(width * height);
    }

    @Override
    public float volume() {

        return (float) depth * width * height;
    }

    @Override
    public String render() {

        return "The volume of the cube is " + volume() + " The surface area is " + surfaceArea();
    }
}
