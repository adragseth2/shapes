package cvtc.edu.shapes;

public class Cylinder extends Shape {



    //declare variables
    float radius = 0;
    float height = 0;


    //constructor
    public Cylinder(float radius, float height) {
        this.radius = radius;
        this.height = height;
    }

    //getters and setters


    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }



    @Override
    public float surfaceArea() {

        return (float) (2.0 * Math.PI * radius * height + (2.0 * Math.PI * Math.pow(radius, 2.0)));
    }

    @Override
    public float volume() {

        return (float) (Math.PI * Math.pow(radius, 2.0) * height);
    }

    @Override
    public String render() {

        return "The surface area of the cylinder is " + surfaceArea() + "." +
                "The volume of the cylinder is " + volume() + ".";
    }
}
